print("Hello");
print("I am Ai, What's Your Name");
Name=input();
print("Hello "+Name+" How are You?");
print(" From which country your are ?");
country=input();
print("OH! That's a nice place");
print("Ok,Introduce Yourself to Me");
Introduction=input();
print("OK");
print("Now Do you Know What We Are Going To Do Today ?");
print("Any Guesses");
Guesses=input();
print("I'll tell you. Today We Are Going To Do CODING");
print("Do You Know Anything About Coding?");
print("In your Words What is CODING? Also Tell me Some of It's Languages.");
A1=input();
print("By Your side Which is the the most Commonly used CODING language?");
Language=input();
print("Ok,"+Language+" is really a very famous Language");
print("As I am a Robot I am also made by coding")
print("By the way,Have You ever done CODING Before");
Answer = input();
print("I am Going To Tell You About Some online CODING Classes available on The Internet");
print("By the ratings on the Internet I Can Tell You That WHITE HAT JR.,CAMP K 12,LIDO LEARNING,VEDANTU SUPER CODERS,CODING NINJAS,CODING BUDS,PURPLE TUTOR are some of the most Famous CODING classes on The Internet ")
